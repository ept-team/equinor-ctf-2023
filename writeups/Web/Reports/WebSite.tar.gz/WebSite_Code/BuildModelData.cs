using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.Text;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Loader;
using WebSite.Models;

public class BuildModelData
{

    public ReportDataModel BuildAndRun(string assemblyPath, string code, string connectionstring)
    {
        var codeString = SourceText.From(code);
        var options = CSharpParseOptions.Default.WithLanguageVersion(LanguageVersion.CSharp10);

        var parsedSyntaxTree = SyntaxFactory.ParseSyntaxTree(codeString, options);

        var references = new List<MetadataReference>
            {
                MetadataReference.CreateFromFile(typeof(object).Assembly.Location),
                MetadataReference.CreateFromFile(typeof(Console).Assembly.Location)
            };

        Assembly.GetEntryAssembly()?.GetReferencedAssemblies().ToList()
            .ForEach(a => references.Add(MetadataReference.CreateFromFile(Assembly.Load(a).Location)));
        
        var location = Assembly.GetEntryAssembly().Location;
        
        references.Add(MetadataReference.CreateFromFile(Path.GetDirectoryName(location) + "/Microsoft.EntityFrameworkCore.dll"));
        references.Add(MetadataReference.CreateFromFile(Path.GetDirectoryName(location) + "/System.Data.SqlClient.dll"));
        references.Add(MetadataReference.CreateFromFile(Path.GetDirectoryName(location) + "/System.Data.Common.dll"));
        references.Add(MetadataReference.CreateFromFile(Path.GetDirectoryName(location) + "/netstandard.dll"));
        references.Add(MetadataReference.CreateFromFile(Path.GetDirectoryName(location) + "/System.ComponentModel.Primitives.dll"));
        references.Add(MetadataReference.CreateFromFile(Path.GetDirectoryName(location) + "/WebSite.dll"));
        references.Add(MetadataReference.CreateFromFile(Path.GetDirectoryName(location) + "/System.Collections.dll"));

        var csCompilation = CSharpCompilation.Create(assemblyPath,
            new[] { parsedSyntaxTree },
            references: references,
            options: new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary,
                optimizationLevel: OptimizationLevel.Release,
                assemblyIdentityComparer: DesktopAssemblyIdentityComparer.Default));

        using (var peStream = new MemoryStream())
        {
            var result = csCompilation.Emit(peStream);

            if (result.Success)
            {
                Console.WriteLine("Compilation done without any error.");
                peStream.Seek(0, SeekOrigin.Begin);
                var compiledAssembly = peStream.ToArray();

                using (var asm = new MemoryStream(compiledAssembly))
                {
                    
                    var assemblyLoadContext = new SimpleUnloadableAssemblyLoadContext();
                    var assembly = assemblyLoadContext.LoadFromStream(asm);

                    Type type = assembly.GetType("WebSite.Models.ReportTableModelData");
                    var constructor = type.GetConstructor(Type.EmptyTypes);
                    object classObject = constructor.Invoke(new object[] { });

                    MethodInfo methodInfo = type.GetMethod("CreateModel");
                    var returnValue = methodInfo.Invoke(classObject,new object[]{ connectionstring });
                    return returnValue as ReportDataModel;
                }
            }
        }
        return null;
    }
    internal class SimpleUnloadableAssemblyLoadContext : AssemblyLoadContext
    {
        public SimpleUnloadableAssemblyLoadContext()
            : base(true)
        {
        }

        protected override Assembly Load(AssemblyName assemblyName)
        {
            return null;
        }
    }
}