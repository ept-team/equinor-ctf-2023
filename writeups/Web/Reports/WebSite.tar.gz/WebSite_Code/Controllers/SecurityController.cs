using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;
using Microsoft.Data.Sqlite;
using WebSite.Models;
using System.Configuration;
using System.Linq.Expressions;

namespace WebSite.Controllers;
[Route("api/Login")]
[ApiController]
public class SecurityController : Controller
{
    [HttpPost]
    public void Login([FromBody] LoginModel usermodel)
    {
        try
        {
            using (var con = new SqliteConnection(System.Configuration.ConfigurationManager.ConnectionStrings["ReportDatabase"].ConnectionString))
            {
                var password = Base64Encode(usermodel.password);

                con.Open();
                string query = "SELECT username FROM users where username='" + usermodel.username + "' and password='" + password + "'";
                string user = "";
                using (var cmd = new SqliteCommand(query, con))
                {
                    var datareader = cmd.ExecuteReader();
                    while (datareader.Read())
                    {
                        user = SafeDBReader.SafeGetString(datareader, 0);
                    }
                }
                con.Close();
                if (user != "")
                {
                    var cookieOptions = new CookieOptions();
                    cookieOptions.Expires = DateTime.Now.AddDays(1);
                    cookieOptions.Path = "/";
                    Response.Cookies.Append("Role", "Admin", cookieOptions);
                }
            }
            Response.StatusCode = 200;


        }
        catch (Exception e)
        {
            Response.StatusCode = 500;
        }
    }

    private string Base64Encode(string plainText)
    {
        var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
        return System.Convert.ToBase64String(plainTextBytes);
    }
}