using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;
using Microsoft.Data.Sqlite;
using WebSite.Models;
using System.Configuration;
using Microsoft.AspNetCore.Authorization;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Configuration;

namespace WebSite.Controllers;
[Route("api/Data")]
[ApiController]
public class DataController : Controller
{
    // 
    // GET: /HelloWorld/
    [HttpGet]
    public List<string> Index()
    {
        return new List<string>();
    }

    [HttpPost]
    [Host("localhost:*", "reports.ept.gg:*")]
    public void UpdateReports([FromBody] CreateReportDataModel report)
    {
        try
        {
            string? validUser = Request.Cookies["Role"];
            if (validUser != null && validUser == "Admin")
            {
                if (report.code.Contains("System.IO"))
                {
                    Response.StatusCode = 200;
                }
                else
                {
                    IConfiguration AppSetting = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();

                    using (var con = new SqliteConnection(AppSetting.GetSection("ConnectionStrings").GetValue<string>("ReportDatabase")))
                    {
                        con.Open();
                        string query = "insert into Reports(id,name,code) values (@id, @name, @code)";
                        using (SqliteCommand cmd = new SqliteCommand(query, con))
                        {
                            cmd.Parameters.Add(new SqliteParameter("id", report.id));
                            cmd.Parameters.Add(new SqliteParameter("name", report.name));
                            cmd.Parameters.Add(new SqliteParameter("code", report.code));
                            var datareader = cmd.ExecuteNonQuery();
                        }
                        con.Close();
                    }
                    Response.StatusCode = 200;
                }
            }
            else
            {
                Response.StatusCode = 401;
            }
        }
        catch (Exception e)
        {
            Response.StatusCode = 500;
        }
    }

}

