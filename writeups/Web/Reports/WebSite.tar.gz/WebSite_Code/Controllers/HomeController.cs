using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;
using Microsoft.Data.Sqlite;
using WebSite.Models;
using System.Configuration;

namespace WebSite.Controllers;
[Route("api/Home")]
[ApiController]
public class HomeController : Controller
{
    private IConfiguration configuration;
    public HomeController(IConfiguration iConfig)
    {
        configuration = iConfig;
    }
    // 
    // GET: /HelloWorld/
    public List<string> Index()
    {
        var reports = new List<string>();
        using (var con = new SqliteConnection(configuration.GetSection("ConnectionStrings").GetSection("ReportDatabase").Value))
        {

            con.Open();
            string query = "SELECT name FROM reports";
            using (var cmd = new SqliteCommand(query, con))
            {
                var datareader = cmd.ExecuteReader();
                while (datareader.Read())
                {
                    reports.Add(SafeDBReader.SafeGetString(datareader, 0));
                }
            }
            con.Close();
        }
        return reports;
    }
}