using System;
using System.Collections.Generic;


namespace WebSite.Models
{

    public class ReportDataModel
    {
        public ReportDataModel(){
            Headers = new List<string>();
            Data = new List<List<string>>();
        }
        public List<string> Headers {get; set;}
        public List<List<string>> Data {get; set;}

        public string Title {get; set;} 

    }
}