using System;
using System.Collections.Generic;


namespace WebSite.Models
{

    public class LoginModel
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}