using System;
using System.Collections.Generic;


namespace WebSite.Models
{

    public class CreateReportDataModel
    {
        public string id { get; set; }
        public string name { get; set; }
        public string code { get; set; }
    }
}