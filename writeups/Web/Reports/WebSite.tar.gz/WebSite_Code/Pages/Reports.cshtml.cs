using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data;
using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;
using System.IO;
using WebSite.Models;

namespace WebSite.Pages
{
    public class ReportModel : PageModel
    {
        public ReportDataModel htmlcode { get; set; }

        public string id { get; set; }

        private readonly IConfiguration _configuration;
        public ReportModel(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void OnGet()
        {
            var path = Request.Query["id"][0];
            if (path != null)
            {
                string code = "";
                using (var con = new SqliteConnection(_configuration.GetConnectionString("ReportDatabase")))
                {
                    con.Open();
                    string query = "SELECT * FROM reports where name = @name";
                    using (var cmd = new SqliteCommand(query, con))
                    {
                        cmd.Parameters.Add(new SqliteParameter("name", path));
                        var datareader = cmd.ExecuteReader();
                        while (datareader.Read())
                        {
                            code = datareader.GetString(2);
                        }
                    }
                    con.Close();
                }
                if (code != "")
                {
                    // ugly fix to code
                    code = code.Replace("\\n", "\n");
                    var builder = new BuildModelData();

                    htmlcode = builder.BuildAndRun("name.dll", code, _configuration.GetConnectionString("ReportDatabase"));
                }
                else
                {
                    htmlcode = new ReportDataModel();
                }

            }
        }
    }
}
