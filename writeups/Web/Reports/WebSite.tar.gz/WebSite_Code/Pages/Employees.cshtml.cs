using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data;
using Microsoft.Extensions.Configuration;

namespace WebSite.Pages
{
    public class EmployeesModel2 : PageModel
    {
        private readonly IConfiguration _configuration;
        public EmployeesModel2(IConfiguration configuration)
        {
            _configuration = configuration;
        }
       
        public void OnGet()
        {
        }
    }
}
