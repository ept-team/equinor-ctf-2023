from hashlib import sha256
import random
import base64


def get_random(num):
    return random.randbytes(num)


def main(flag):
    rand = get_random(8)
    
    flag = list(flag)

    for i in range(len(flag) - len(rand) + 1):
        for j in range(len(rand)):
            flag[i+j] = flag[i+j] ^ rand[j]

    out = bytes(flag)
    with open("output.txt", "wb") as f:
        f.write(base64.b64encode(out))


if __name__=='__main__':
    with open("flag.txt", "rb") as f:
        flag = f.read()

    # Verify flag integrity
    if sha256(flag).digest() == b'\x057\xa2\xe4\xbb\xd8\xa8\x84|1\x82\xbd\xe3\x0c\x9c{t\x1b\n\x14\xf2\xcc\xf0\xefR\x9c\xefvo3\x03\xa9':
        main(flag)