#!/bin/sh

ip route delete all
ip route add default via 192.168.1.254
while true
do
    /entrypoint.sh ocserv -c /etc/ocserv/ocserv.conf -f
done
