#!/bin/sh

echo root:trust_but_verify | chpasswd
apt-get update
apt-get install -y openssh-server
service ssh start
sleep 10000000
