#!/bin/sh

ip route delete all
ip route add default via 192.168.2.254
while true
do
    openconnect --servercert sha256:fc21 --authgroup=Route --user=flag --passwd-on-stdin https://192.168.1.2 < /etc/flag.txt
    sleep 10
done
